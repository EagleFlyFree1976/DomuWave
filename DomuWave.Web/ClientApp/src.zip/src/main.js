import { createApp } from 'vue'
import { createPinia } from 'pinia'
import PrimeVue from 'primevue/config'
import Aura from '@primeuix/themes/aura'
import ToastService from 'primevue/toastservice'
import Tooltip from 'primevue/tooltip'

import router from '@/router'
import App from './App.vue'

// PrimeVue styles
import 'primeicons/primeicons.css'

const app = createApp(App)
const pinia = createPinia()

app.use(pinia)
app.use(router)
app.use(PrimeVue, {
  theme: {
    preset: Aura,
    options: {
      darkModeSelector: 'html.p-dark',
      cssLayer: false,
    },
  },
})
app.use(ToastService)
app.directive('tooltip', Tooltip)

// Apply dark theme by default
document.documentElement.classList.add('p-dark')

app.mount('#app')
