<template>
  <!-- Blank layout (Login, 404, ecc.) -->
  <RouterView v-if="isBlankLayout" />

  <!-- App layout con sidebar -->
  <AppLayout v-else />
</template>

<script setup>
import { computed } from 'vue'
import { useRoute } from 'vue-router'
import AppLayout from '@/components/layout/AppLayout.vue'

const route = useRoute()

// Routes with meta.layout === 'blank' bypass the sidebar layout
const isBlankLayout = computed(() => route.meta?.layout === 'blank')
</script>
