import { createRouter, createWebHistory } from 'vue-router'
import { useAuthStore } from '@/stores/authStore'

const routes = [
  { path: '/', redirect: '/dashboard' },

  // ── Pubblica (no auth) ──────────────────────────────────────────────────
  {
    path: '/login',
    component: () => import('@/views/LoginView.vue'),
    meta: { title: 'Accedi', public: true, layout: 'blank' },
  },

  // ── Protette ────────────────────────────────────────────────────────────
  { path: '/dashboard', component: () => import('@/views/DashboardView.vue'), meta: { title: 'Dashboard', requiresAuth: true } },
  { path: '/condomini', component: () => import('@/views/CondominiView.vue'), meta: { title: 'Condomini', requiresAuth: true } },
  { path: '/condomini/:id', component: () => import('@/views/CondominioDetailView.vue'), meta: { title: 'Dettaglio Condominio', requiresAuth: true } },
  { path: '/unita', component: () => import('@/views/UnitaView.vue'), meta: { title: 'Unità Immobiliari', requiresAuth: true } },
  { path: '/budget', component: () => import('@/views/BudgetView.vue'), meta: { title: 'Budget & Spese', requiresAuth: true } },
  { path: '/rate', component: () => import('@/views/RateView.vue'), meta: { title: 'Rate & Quote', requiresAuth: true } },
  { path: '/fornitori', component: () => import('@/views/FornitoriView.vue'), meta: { title: 'Fornitori', requiresAuth: true } },
  { path: '/documenti', component: () => import('@/views/DocumentiView.vue'), meta: { title: 'Documenti', requiresAuth: true } },
  { path: '/comunicazioni', component: () => import('@/views/ComunicazioniView.vue'), meta: { title: 'Comunicazioni', requiresAuth: true } },
]

const router = createRouter({
  history: createWebHistory(),
  routes,
})

// ── Navigation guard ────────────────────────────────────────────────────────
router.beforeEach((to, _from, next) => {
  const authStore = useAuthStore()

  // Già loggato e prova ad andare al login → manda al dashboard
  if (to.meta.public && authStore.isAuthenticated) {
    return next({ path: '/dashboard' })
  }

  // Route protetta senza token → manda al login ricordando la destinazione
  if (to.meta.requiresAuth && !authStore.isAuthenticated) {
    return next({ path: '/login', query: { redirect: to.fullPath } })
  }

  next()
})

// ── Titolo pagina ────────────────────────────────────────────────────────────
router.afterEach((to) => {
  document.title = to.meta.title ? `${to.meta.title} · DomuWave` : 'DomuWave'
})

export default router
