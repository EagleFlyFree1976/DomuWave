<template>
  <div class="app-layout">
    <AppSidebar />

    <div class="app-main">
      <!-- Topbar -->
      <header class="app-topbar">
        <div class="topbar-left">
          <Breadcrumb :model="breadcrumbItems" class="topbar-breadcrumb">
            <template #item="{ item }">
              <RouterLink v-if="item.to" :to="item.to" class="breadcrumb-link">
                {{ item.label }}
              </RouterLink>
              <span v-else class="breadcrumb-current">{{ item.label }}</span>
            </template>
          </Breadcrumb>
        </div>
        <div class="topbar-right">
          <slot name="topbar-actions" />
        </div>
      </header>

      <!-- Page content -->
      <main class="app-content">
        <RouterView v-slot="{ Component }">
          <Transition name="page" mode="out-in">
            <component :is="Component" />
          </Transition>
        </RouterView>
      </main>
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import { useRoute } from 'vue-router'
import AppSidebar from '@/components/layout/AppSidebar.vue'
import Breadcrumb from 'primevue/breadcrumb'

const route = useRoute()

const breadcrumbItems = computed(() => {
  const items = [{ label: 'Home', to: '/dashboard' }]
  if (route.meta?.breadcrumb && route.meta.breadcrumb !== 'Dashboard') {
    items.push({ label: route.meta.breadcrumb })
  }
  return items
})
</script>

<style scoped>
.app-layout {
  display: flex;
  min-height: 100vh;
  background: var(--surface-ground);
}

.app-main {
  flex: 1;
  display: flex;
  flex-direction: column;
  min-width: 0;
  overflow: hidden;
}

.app-topbar {
  height: 60px;
  background: var(--surface-card);
  border-bottom: 1px solid var(--surface-border);
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 1.5rem;
  position: sticky;
  top: 0;
  z-index: 5;
}

.topbar-breadcrumb :deep(.p-breadcrumb) {
  background: transparent;
  border: none;
  padding: 0;
}
.topbar-breadcrumb :deep(.p-breadcrumb-list) {
  gap: 0.25rem;
}

.breadcrumb-link {
  color: var(--text-color-secondary);
  text-decoration: none;
  font-size: 0.875rem;
  transition: color 0.15s;
}
.breadcrumb-link:hover {
  color: var(--primary-400);
}
.breadcrumb-current {
  font-size: 0.875rem;
  color: var(--text-color);
  font-weight: 600;
}

.app-content {
  flex: 1;
  padding: 1.5rem;
  overflow-y: auto;
}

/* ── Page transition ─────────────────────────────────────────────────────── */
.page-enter-active,
.page-leave-active {
  transition: opacity 0.18s ease, transform 0.18s ease;
}
.page-enter-from {
  opacity: 0;
  transform: translateY(8px);
}
.page-leave-to {
  opacity: 0;
  transform: translateY(-4px);
}
</style>
